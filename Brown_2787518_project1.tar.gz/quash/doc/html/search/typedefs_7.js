var searchData=
[
  ['redirect',['Redirect',['../parsing__interface_8h.html#a67fb1576f7860fc183192b57b79f91ce',1,'parsing_interface.h']]]
];
