var searchData=
[
  ['redirect',['Redirect',['../structRedirect.html',1,'']]]
];
